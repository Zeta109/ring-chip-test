Ringtest auf Cloudflare, Lauf vom 9. November 2026 / Ring test on Cloudflare, run of 9 November 2026
DE: ringtest_rohdaten.json = Rohdaten aller 6 Läufe, so wie die Server sie geliefert haben. Berichte DE/EN sind daraus gerechnet. worker.js und page.txt sind der Code der Server und der Seite, seal.json die Vorhersagen, PREDICTION_WELTLAUF.txt die vorab veröffentlichte Vorhersage.
Nachprüfen: SHA256SUMS.txt mit "sha256sum -c SHA256SUMS.txt" prüfen; jeden Schritt aus ringtest_rohdaten.json mit der Regel nachrechnen (siehe Bericht).
EN: ringtest_rohdaten.json = raw data of all 6 runs exactly as delivered by the servers. The DE/EN reports are computed from it. worker.js and page.txt are the code of the servers and of the page, seal.json holds the predictions, PREDICTION_WELTLAUF.txt the prediction published beforehand.
Verify: check SHA256SUMS.txt with "sha256sum -c SHA256SUMS.txt"; recompute every step in ringtest_rohdaten.json with the rule (see report).
